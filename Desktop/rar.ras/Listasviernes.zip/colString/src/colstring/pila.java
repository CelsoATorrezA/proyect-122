
package colstring;

public class pila {
	private int tope, max;
	Object v[]=new Object[100];
	
	public pila(int cp) {
		tope =0;
		max=cp;
	}
	public void mostrar() {
		Object elem;
		pila aux=new pila(max);
		while (!esvacia()) {
			aux.adicionar(eliminar());
		}
		while (!aux.esvacia()) {
			elem=aux.eliminar();
			System.out.println(elem);
			adicionar(elem);}}
	public int nElem() {
		return tope;}
	Object eliminar() 
	{
		Object dato=null;
		if(esvacia()) {
			System.out.println("pila vacia");
		}
		else {
			dato=v[tope];
			tope--;
		}
		return dato;
	}
	public void adicionar(Object elem) {
		if(!esllena()) {
			tope++;
			v[tope]=elem;
		}
		else {
			System.out.println("pila llena");
		}
	}
	public boolean esllena() {
		if (tope==max) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean esvacia() {
		if (tope==0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void vaciar(pila B) // vacíalaPila B enlapila actual
	{
		while (!B.esvacia())
			adicionar(B.eliminar());
	}
	int nElem1() // devuelve el númerodeelementosdelapila
	{
		return tope;
	}
	boolean buscar(Object x) {
		Object da;
		boolean sw=false;
		pila auxPila=new pila(max);
		while(! this.esvacia()) {
			da=eliminar();
			auxPila.adicionar(da);
			if(da.equals(x)) {
				sw=true;
			}
		}
		vaciar(auxPila);
		return sw;
	}
	int getmax() {
		return max;
        }


}
