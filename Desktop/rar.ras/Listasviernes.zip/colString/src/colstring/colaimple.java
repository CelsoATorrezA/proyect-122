
package colstring;

public abstract class colaimple {
    public int ini,fin,max;
    Object v[]= new Object[100];
    
    colaimple(int cap){
        ini=0;
        max=cap;
        fin=0;
    }
    abstract boolean esVacia();
    abstract boolean esLlena();
    abstract void adicionar(Object x);
    abstract Object eliminar();
    abstract void mostrar();
    abstract int nElem();

    public int getIni() {
        return ini;
    }

    public void setIni(int ini) {
        this.ini = ini;
    }

    public int getFin() {
        return fin;
    }

    public void setFin(int fin) {
        this.fin = fin;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public Object[] getV() {
        return v;
    }

    public void setV(Object[] v) {
        this.v = v;
    }
    
}
