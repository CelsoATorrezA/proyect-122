/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colstring;

import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class libro {
    Scanner lee=new Scanner(System.in);
    private String nombre,editorial,autor;
    private int añopublicacion;

    public libro(String nombre, String editorial, String autor, int añopublicacion) {
        this.nombre = nombre;
        this.editorial = editorial;
        this.autor = autor;
        this.añopublicacion = añopublicacion;
    }

    public libro() {
    }
    void leer(){
        System.out.println("NOMBRE DEL LIBRO: ");
        nombre=lee.next();
        System.out.println("EDITORIAL: ");
        editorial=lee.next();
        System.out.println("AUTOR: ");
        autor=lee.next();
        System.out.println("Año Publicacion: ");
        añopublicacion=lee.nextInt();
        
    }
    public String toString(){
        return "Nombre Libro: "+nombre+" "+"Editorial:"+editorial+" "+"Autor: "+autor+" "+"Año publicacion: "+añopublicacion; 
    }
    void mostrar(){
        System.out.println("Nombre Libro: "+nombre+" "+"Editorial:"+editorial+" "+"Autor: "+autor+" "+"Año publicacion: "+añopublicacion);
    }

    public String getNombre_libro() {
        return nombre;
    }

    public void setNombre_libro(String nombre) {
        this.nombre = nombre;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAñopublicacion() {
        return añopublicacion;
    }

    public void setAñopublicacion(int añopublicacion) {
        this.añopublicacion = añopublicacion;
    }
    
    
    
}
