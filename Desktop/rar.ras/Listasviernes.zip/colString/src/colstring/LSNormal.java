
package colstring;

import java.util.Scanner;

public class LSNormal extends LSimple1 {
    Scanner lee=new Scanner(System.in);
LSNormal()
{
super();
}
boolean esVacia(){
return(super.esVacia());}
NodoS getCabecera(){
return p;}
void setCabecera(NodoS q)
{p=q;}
void adiFin(Object da){
NodoS x,u;
x=new NodoS();
x.setDato(da);
if (esVacia()) p=x;
else {u=p;
 while(u.getSig()!=null)
 u=u.getSig();
 u.setSig(x);} }
void adiPrimero(Object da)
{ NodoS y;
y=new NodoS(); 
y.setDato(da);
y.setSig(p);
p=y;}
Object eliFin(){
NodoS au=null,y,u;
Object Da=null;
if(esVacia()) System.out.println("Lista vacia");
else {u=p;
while(u.getSig()!=null){au=u;
u=u.getSig();}
Da=u.getDato();
if(p==u) p=null;
 else au.setSig(null);}
return Da;}
int nElem(){
NodoS x;int cont;
if (esVacia()) cont=0;
else {
 x=p;cont=1;
 while (x.getSig()!= null){
 cont++;
 x=x.getSig();} }
return cont;}
Object eliPrimero(){
Object da=null;
if (!esVacia()){
da=p.getDato();
p=p.getSig();}
else System.out.println("Lista vacia...");
return da;}
void mostrar()
{NodoS y;
if (esVacia()) System.out.println("Lista vacia");
else {y=p;
 while(y!=null)
 {System.out.print("\t"+y.getDato());
 y=y.getSig();}}}
void llenarInt(){
    System.out.println("Cantidad de elementos de la lista:");
        int mn=lee.nextInt();
        for(int i=0;i<mn;i++){
           int da=lee.nextInt();
            this.adiFin(da);
        }
}
void llenarString(){
    System.out.println("Cantidad de elementos de la lista:");
        int mn=lee.nextInt();
        for(int i=0;i<mn;i++){
           String da=lee.next();
            this.adiFin(da);
        }
}
void llenarChar(){
    System.out.println("Cantidad de elementos de la lista:");
        int mn=lee.nextInt();
        for(int i=0;i<mn;i++){
           String da=lee.next();
           char carac=da.charAt(0);
            this.adiFin(carac);
        }
}
void adicionarDespuesDeK(int k, Object da) {
        NodoS nuevoNodo = new NodoS();
        nuevoNodo.setDato(da);
        if (esVacia()) {
            if (k == 0) {
                p = nuevoNodo;
            } else {
                System.out.println("La lista está vacía. No se puede agregar después del nodo " + k);
                return;
            }
        } else {
            NodoS actual = p;
            int contador = 0;
            while (actual != null && contador < k) {
                actual = actual.getSig();
                contador++;
            }
            if (actual != null) {
                nuevoNodo.setSig(actual.getSig());
                actual.setSig(nuevoNodo);
            } else {
                System.out.println("El nodo " + k + " no existe en la lista.");
            }
        }
    }
 void adicionarAntesDeK(int k, Object da) {
        NodoS nuevoNodo = new NodoS();
        nuevoNodo.setDato(da);
        if (esVacia()) {
            if (k == 0) {
                p = nuevoNodo;
            } else {
                System.out.println("La lista está vacía. No se puede agregar antes del nodo " + k);
                return;
            }
        } else {
            if (k == 0) {
                nuevoNodo.setSig(p);
                p = nuevoNodo;
            } else {
                NodoS actual = p;
                int contador = 0;

                while (actual != null && contador < k - 1) {
                    actual = actual.getSig();
                    contador++;
                }
                if (actual != null) {
                    nuevoNodo.setSig(actual.getSig());
                    actual.setSig(nuevoNodo);
                } else {
                    System.out.println("El nodo " + k + " no existe en la lista.");
                }
            }
        }
    }
 void DuplicarKveces(){
     LSNormal aux=new LSNormal();
     LSNormal aux2=new LSNormal();
     LSNormal aux3=new LSNormal();
     NodoS x;
     x=new NodoS();
     System.out.println("Ingres el dato que quiere añadir:");
     String dato=lee.next();
     char carac=dato.charAt(0);
     System.out.println("Ingres por cual quiere cambiar:");
     String dato2=lee.next();
     char carac2=dato2.charAt(0);
     System.out.println("Ingrese cuantas veces quiere añadir:");
     int ele=lee.nextInt();
     for(int i=1;i<=this.nElem();i++){
         char ca=(char)this.eliPrimero();
         if(ca == carac2){
             for(int j=1;j<=ele;j++){
                 aux.adiFin(carac);
             }
         }
         this.adiFin(ca);
     }
     while(!this.esVacia()){
         char ca=(char)this.eliPrimero();
         if(ca == carac2){
             while(!aux.esVacia()){
                 aux2.adiFin(aux.eliPrimero());
             }
             
         }else{
             aux2.adiFin(ca);
         }
     } 
     while(!aux2.esVacia()){
         this.adiFin(aux2.eliPrimero());
     }
    this.mostrar();
 }

        
}

