/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colstring;

import java.util.Scanner;

/**
 *
 * @author Celso Torrez
 */
public class ColString {

    public static void main(String[] args) {
        Scanner lee=new Scanner(System.in);
       /* CSNormal a=new CSNormal(100); 
       int can=lee.nextInt();
        for(int i=0;i<can;i++){
            libro l1=new libro();
            l1.leer();
            a.adicionar(l1);
        }
        a.mostrar();
        System.out.println("................");
        a.ejer1();
         colascircular c1=new colascircular(100);
        colascircular c2=new colascircular(100);    
        System.out.println("MAYOR Y MENOR AL PROMEDIO:");
        c1.llenar();
        System.out.println("EL PROMEDIO DE LA COLA ES : ");
        System.out.println(c1.promedioCOLA());
        c1.divirPromedio();
        System.out.println("CADENAS: ");
        c2.llenarString();
        System.out.println("EJCERCICIO: ");
        c2.eliminarvocales();
        //c1.llenar();
        //c2.llenarString();
        //System.out.println("COLA CSCIRCULA RESULTANTE 1: ");
        //c1.mostrar();
        //System.out.println("ORDENA cola 2 ");
        //c2.mostrar();
        //System.out.println("impares adelante pares atras: ");
        //c1.paFrontimpbhind();
        //c1.mostrar();
        
        //c1.OrdenarAscendentemente();
        //c1.mostrar();
        //c1.polinomio();
        //System.out.println("Intercalar colas: ");
        //c1.intercalar(c2);
        /*System.out.println("intercambiar:::::::");
        c1.intercambiarIyJ(c2);
        System.out.println("C1:");
        c1.mostrar();
        System.out.println("C2:");
        c2.mostrar();
        System.out.println("inviritendo::");
        c1.invertir();*/
       /*colascircular cc1=new colascircular(100);
       colascircular cc2=new colascircular(100);
       
       cc1.llenarpersona();
       System.out.println("COLA DE PERSONAS: ");
       cc1.mostrar();
        cc2.llenarHistoria(cc1);
        System.out.println("COLA MOSTRADA de HISTORIA:");
        cc2.mostrar();
        System.out.println("----------------------------------");
        System.out.println("Cantidad de atentidos y ingreso");
        cc2.encisoB();
        System.out.println("Total ingreso de todas las especialidades:");
        cc2.encisoC();
        System.out.println("Especialida que mas genera: ");
        cc2.encisoD();
        System.out.println("Especialida que menos genera:");
        cc2.encisoE();
        System.out.println("Mujeres y Hombres Atentidos");
        cc1.encisoF();
        System.out.println("Especialidad con menor consultas: ");
        cc2.encisoG();*/
        LSNormal ls1=new LSNormal();
        LSNormal ls2=new LSNormal();
        LSNormal ls3=new LSNormal();
        System.out.println("Lista de enteros:");
       /*ls1.llenarInt();
        System.out.println("Lista de Cadenas:");
       ls2.llenarString();
        
        System.out.println("---------------------------");
        System.out.println("\n enteros:");
        ls1.mostrar();
        ls1.adicionarAntesDeK(2, 6);
        System.out.println("\n");
        ls1.mostrar();
        ls1.adicionarAntesDeK(3, 5);
        System.out.println("\n");
        ls1.mostrar();*/
        /*System.out.println("\n Cadenas:");
        ls2.mostrar();
        */
        System.out.println("\n Lista de caractere:");
       ls3.llenarChar();
        System.out.println("\n Caracteres:");
        ls3.mostrar();
        System.out.println("\n--------------------------------------");
        ls3.DuplicarKveces();
        
       
    }
    
}
