
package colstring;

public class CSNormal extends colaimple {

    CSNormal(int cap)
    {
        super(cap);
    }
    boolean esVacia(){
        if(ini==0){
            return true;
        }
        else{
            return false;
        }
    }
    boolean esLlena(){
        if(fin==max){
            return true;
        }
        else{
            return false;
        }
    }
    void adicionar(Object ele){
        if(!esLlena()){
            if(esVacia()){
                ini=1;
            }
            fin++;
            v[fin]=ele;
        }

    }
 Object eliminar(){
    Object ele=null;
    if(!esVacia()){
                ele=v[ini];
                ini=ini+1;
                if(ini>fin){
                    ini=0;
                    fin=0;
                }        
            }
            else{
                System.out.println("Cola vacia");
            }
            return ele;                      
    }
 void mostrar(){
     Object elem;
     CSNormal  aux=new CSNormal(max);
     while(!esVacia()){
         elem=eliminar();
         
         System.out.println(elem);
         aux.adicionar(elem);
     }
     while(!aux.esVacia()){
         adicionar(aux.eliminar());
     }
 }
 int nElem(){
     int ne=0;
     if(!esVacia()){
         ne=fin-ini+1;
     }
     return ne;
 }
 int MaximoCola(){
     CSNormal aux=new CSNormal(100);
     int maximo=-10,numero;
     while(!this.esVacia()){
         numero=(int)this.eliminar();
         if(maximo<numero){
             maximo=numero;
         }
         aux.adicionar(numero);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     return maximo;
 }
 double promedioCOLthis(){
     CSNormal aux=new CSNormal(100);
     int sum=0,numero;
     while(!this.esVacia()){
         numero=(int)this.eliminar();
         sum=sum+numero;
         aux.adicionar(numero);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     return (double)sum/(double)nElem();
 }
 void invertir(){  
     pila aux=new pila(100);
     
     while(!this.esVacia()){
         aux.adicionar((int)this.eliminar());
     }
     while(!aux.esvacia()){
         this.adicionar(aux.eliminar());
     }
     
 }
 void ordenarthisSC(){
     CSNormal aux=new CSNormal(100);
     CSNormal aux2=new CSNormal(100);
     int min=999;
     while(!this.esVacia()){
         int dato=(int)this.eliminar();
         if(dato<min){
             min=dato;
            aux.adicionar(dato);
         }else{
             
         }
            
         
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     
 }
 int elementoFIN(){
     if(fin>=0){
         return (int)v[fin];
     }else{
         throw new IllegalStateException("Cola vacia");
     }     
 }
 /*void MayusculaPrimera(){
     CSNormal aux=new CSNormal(100);
     
     String cm="";
     while(!this.esVacia()){
         String dato=(String)this.eliminar();
         
         char character=dato.charthist(0);
         char newchar=Character.toUpperCase(character);
         String  Stringnew= newchar+dato.toLowerCase().substring(1);
         aux.adicionar(Stringnew);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     this.mostrar();
 }
 /*void intercambiar(CSNormal b){
     CSNormal aux = new CSNormal(100);
        CSNormal auxint = new CSNormal(100);
        CSNormal auxVeri = new CSNormal(100);
        
        while(!esVacia()){
            String palabraMes= "";
            String pal = "";
            String palaDef = "";
            int numero =(int)b.eliminar();
            String cad = (String)this.eliminar();
            String numCom = String.valueOf(numero);
            for (int i = 0; i < cad.length(); i++) {
                char caracter = cad.charthist(i);
                pal= caracter +numCom;
                palabraMes = palabraMes +pal;      
            }
            
            for (int i = 0; i < palabraMes.length()-1; i++) {
                char carac = palabraMes.charthist(i);
                palaDef = palaDef+carac;
            }
            aux.adicionar(cad);
            auxint.adicionar(numero);
            auxVeri.adicionar(palaDef);
            
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        while(!auxint.esVacia()){
            b.adicionar(auxint.eliminar());
        }
        
        auxVeri.mostrar();
 }
 /*void verificarCorre(){
        CSNormal aux = new CSNormal(100);
        CSNormal auxVeri = new CSNormal(100);
        CSNormal auxint = new CSNormal(100);
        CSNormal auxintPal = new CSNormal(100);
        String corrVeri = "gmail.com";
        
        for (int i = 0; i < corrVeri.length(); i++) {
            char caracter = corrVeri.charthist(i);
            int ascii = (int) caracter;
            auxint.adicionar(ascii);
        }
        

        while(!this.esVacia()){
            boolean sw = false;
            String cadena = (String)this.eliminar();
            
            int indiceGuion = cadena.indexOf('@'); //posición
            String subcadena = " ";
            if(indiceGuion == 0){
                subcadena = " ";
            }else{
                subcadena = cadena.substring(indiceGuion + 1);
            } 
            
            if(!subcadena.equals(" ")){
               for (int i = 0; i < subcadena.length(); i++) {
                    char caracter = subcadena.charthist(i);
                    int ascii = (int) caracter;
                    auxintPal.adicionar(ascii);
                   
                } 
            }
            
            
            // comparar colas
            int cont = auxint.nElem();
            int contSe = auxintPal.nElem();
            if(cont> contSe){
                for (int i = 0; i < auxint.nElem(); i++) {
                    int num = (int)auxint.eliminar();
                    int numero =(int) auxintPal.eliminar();
                    if(num == numero){
                        sw = true;
                    }else
                        sw= false;
                    auxint.adicionar(num);
                }
            }else{
                for (int i = 0; i < auxintPal.nElem(); i++) {
                    int num = (int)auxint.eliminar();
                    int numero =(int) auxintPal.eliminar();
                    if(num == numero){
                        sw = true;
                    }else
                        sw= false;
                    auxint.adicionar(num);
                }
            }
                
            
            auxintPal.setFin(0);
            auxintPal.setIni(0);
            
            if(sw){
                auxVeri.adicionar("ok");
            }else
                auxVeri.adicionar("no");
            
            aux.adicionar(cadena);
            
        }
        auxVeri.mostrar();
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
      
    }*/
 void  ordenar2(){
     
 
    { CSNormal a=new CSNormal(100);
      CSNormal b=new CSNormal(100);
      while(! this.esVacia())
      {  libro  may=(libro)this.eliminar();
         while(! this.esVacia())
         {   libro ex=(libro)this.eliminar();
             if(ex.getAñopublicacion()<may.getAñopublicacion())
             {   a.adicionar(may);
                 may=ex;
             }
             else
             {  a.adicionar(ex);
             }   
         }
         b.adicionar(may);
         while(!a.esVacia()){
             this.adicionar(a.eliminar());
         }
         
      }
      while(!b.esVacia()){
          this.adicionar(b.eliminar());
      }
     
      //this.mostrar();
    }
 } 
     
    int verifica(String x,String y)
     {
         CSNormal a=new CSNormal(100);
         int cont=0;
         
         while(!this.esVacia())
         {
             libro lx=(libro)this.eliminar();
             if(lx.getNombre_libro().equals(x) && lx.getAutor().equals(y) )
             {
                 cont++;
             }
             a.adicionar(lx);
                 
         }
         while(!a.esVacia()){
             this.adicionar(a.eliminar());
         }
         
         return cont;
     }
     /*public static int mayorthis(CSNormal this)
     {
         CSNormal a=new CSNormal();
         int may=0;
         
         while(! this.esVacia())
         {
             libro lx=this.eliminar();
             if(lx.getthisño()>may)
             {
                 may=lx.getthisño();
             }
             a.adicionar(lx);
                 
         }
         this.vaciar(a);
         return may;
     }*/
     
      void ejer1()
     {
         CSNormal a=new CSNormal(100);
         CSNormal b=new CSNormal(100);
         
         //int may=mayorthis(this);
         this.ordenar2();
         //this.mostrar();
         
         while(! this.esVacia())
         {
             libro lx=(libro)this.eliminar();
             a.adicionar(lx);
             b.adicionar(lx);
         }
         while(!a.esVacia()){
             this.adicionar(a.eliminar());
         }
         
         //b.mostrar();
         while(!this.esVacia())
         {
             libro lx=(libro)this.eliminar();
             
             if(verifica(lx.getNombre_libro(),lx.getAutor())==0 )
             {
                 a.adicionar(lx);
             }
         }
         while(!a.esVacia()){
             this.adicionar(a.eliminar());
         }
         this.mostrar();
     }
 


}
