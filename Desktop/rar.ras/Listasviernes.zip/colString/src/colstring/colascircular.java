
package colstring;

import java.util.Scanner;

public class colascircular extends colaimple{
    Scanner lee=new Scanner(System.in);
    colascircular(int m){
        super(m);
    }
    boolean esVacia(){
        if(nElem()==0){
            return true;
        }
        else{
            return false;
        }
    }
    boolean esLlena(){
        if(nElem()==max-1){
            return true;
        }
        else{
            return false;
        }
    }
    void adicionar(Object x){
        if(!esLlena()){
            fin=(fin+1)%max;
            v[fin]=x;
        }
        else{
            System.out.println("cola llena");
        }
    }
    Object eliminar(){
        Object ele=null;
        if(!esVacia()){
            ini=(ini+1)%max;
            ele=v[ini];
        }
        else{
            System.out.println("cola vacia");
        }
        return ele;
    }
    void mostrar(){
        Object ele;
        int n=nElem();
        if(this.esVacia()){
            System.out.println("COLthis VthisCIthis!");
            
        }else{
            for(int i=1;i<=n;i++){
            ele=eliminar();
            System.out.println(ele);
            this.adicionar(ele);
                }
        }
        
    }
    int nElem(){
        return ((fin-ini+max)%max);
    }
    public Object frente() {
    if (esVacia()) {
        System.out.println("La cola circular está vacía");
        return null;
    }
    
    return v[ini];
}
    //buscar persona X
    void buscar(String x){
        colascircular aux=new colascircular(100);
        for(int i=1;i<=this.nElem();i++){
            persona p1=new persona();
            p1=(persona)this.eliminar();           
            if(p1.getNombre().equals(x)){
                System.out.println("Lthis PERSONthis ESXITE:!");
                System.out.println("su posicion es:"+i);
            }
            this.adicionar(p1);
        }
       
    }
    //ordenar persona
   /* void ordenar2()
    { colascircular a=new colascircular(100);
      colascircular b=new colascircular(100);
      
      
      while(!this.esVacia())
      {  int  may=(persona)this.eliminar();
         while(! this.esVacia())
         {   int ex=(persona)this.eliminar();
             if(ex>may)
             {   a.adicionar(may);
                 may=ex;
             }
             else
             {  a.adicionar(ex);
             }   
         }
         b.adicionar(may);
         this.vaciar(a);
      }
      this.vaciar(b);
      this.mostrar();
    }*/
    //ordenar forma thisscende  y descenden las colas ciruclares

void Ordenarthisscendentemente() {
        colascircular aux = new colascircular(100);
        
        while (!this.esVacia()) {
            
            int nroEle = (int)this.nElem();
            int min = numMinColCir(this);
            
            for (int i = 0; i < nroEle; i++) {
                int numero = (int)this.eliminar();
                if(numero == min){
                    aux.adicionar(numero);
                }else{
                    this.adicionar(numero);
                }  
            }
            
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        
        this.mostrar();
    }
int numMinColCir(colascircular a){
    int min=0;
        colascircular aux = new colascircular(100);
         min = (int)a.eliminar();
        a.adicionar(min);
        while (!a.esVacia()) {            
            int num = (int)a.eliminar();
            if(num< min){
                min = num;
            }
            aux.adicionar(num);
        }
        while(!aux.esVacia()){
            a.adicionar(aux.eliminar());
        }
        return min;    
}

    //llenar datos
    void llenar(){
        System.out.println("Numero de elementos de la cola: ");
        int cd=lee.nextInt();
        for(int i=0;i<cd;i++){
            System.out.println("DthisTO: "+(i+1));
            double da=(double)lee.nextDouble();
            this.adicionar(da);
        }
    }
    //llenar datos
    void llenarString(){
        System.out.println("Numero de elementos de la cola: ");
        int cd=lee.nextInt();
        for(int i=0;i<cd;i++){
            System.out.println("DthisTO: "+(i+1));
            String da=(String)lee.next();
            
            this.adicionar(da);
        }
    }
    //Polinomio de grado N
    void polinomio(){
        
        colascircular exponente=new colascircular(100);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el grado del polinomio: ");
        int grado = scanner.nextInt();
        
        //pedir coeficientes y exponentes del polinomio
        for(int i=0;i<=grado;i++){
            System.out.println("Ingrese el coeficiente para x^"+i+":");
            int coeficiente=scanner.nextInt();
            this.adicionar(coeficiente);
            exponente.adicionar(i);
        }
        //pedir el numero para evaluar el polinomio
        System.out.println("Ingrese un numero para evaluar el polinomio: ");
        int numero=scanner.nextInt();
        //evaluar el polonimo
        int resultado =evaluarPolinomio(this,exponente,numero);
        //Imprimir el resultado
        System.out.println("El resultado de evaluar el polinomio es: "+resultado);
    }
  int evaluarPolinomio(colascircular coeficientes, colascircular exponentes, int numero) {
        int resultado = 0;
        int n = coeficientes.nElem();

        for (int i = 0; i < n; i++) {
            int coeficiente = (int) coeficientes.eliminar();
            int exponente = (int) exponentes.eliminar();

            resultado += coeficiente * Math.pow(numero, exponente);

            coeficientes.adicionar(coeficiente);
            exponentes.adicionar(exponente);
        }

        return resultado;
    }
  //invertir  C DE CthisDENthisS
   void invertir(){  
     pila aux=new pila(100);
     
     while(!this.esVacia()){
         aux.adicionar(this.eliminar());
     }
     while(!aux.esvacia()){
         this.adicionar(aux.eliminar());
     }
     
 }
// inter cambiar sin perder datos es el C DE CCC ENTEROS 
 void intercalar(colascircular c){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     colascircular aux3=new colascircular(100);

     while(!this.esVacia() || !c.esVacia()){
         int num1=(int)this.eliminar();
         int num2=(int)c.eliminar();
         int m1=num1, m2=num2;
         aux2.adicionar(m1);
         aux2.adicionar(m2);
         
         aux.adicionar(num1);
         aux3.adicionar(num2);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     while(!aux3.esVacia()){
         c.adicionar(aux3.eliminar());
     }
     aux2.mostrar();
 }
 //Intercalar i-esimo daot con j.esmio dato
 void intercambiarIyJ(colascircular c){
     System.out.println("INTRODUZCthis I-ESIMO: ");
     int ii=lee.nextInt();
     System.out.println("INTRODUZCthis j-ESIMO: ");
     int jj=lee.nextInt();
     colascircular aux=new colascircular(100);
     String elementoMi="";
     for(int i=0;i<this.nElem();i++){
         String elemento=(String)this.eliminar();
         if(i==ii){
             elementoMi=elemento;
         }
         this.adicionar(elemento);
     }
     String elementoCj="";
     for(int i=0;i<c.nElem();i++){
         String elemento=(String)c.eliminar();
         if(i==jj){
             elementoCj=elemento;
         }
         c.adicionar(elemento);
     }
     for (int k = 0; k < this.nElem(); k++) {
            String elemento = (String) this.eliminar();
            if (k == ii) {
                this.adicionar(elementoCj);
            } else {
                this.adicionar(elemento);
            }
        }
     for (int k = 0; k < c.nElem(); k++) {
            String elemento = (String) c.eliminar();
            if (k == jj) {
                c.adicionar(elementoMi);
            } else {
                c.adicionar(elemento);
            }
        }
 }
 //inverti k elementos()
 void invertirKelem(){
     pila c=new pila(100);
     System.out.println("Introduzca K: ");
     int k=lee.nextInt();
     int n=this.nElem();
     for(int i=0;i<k;i++){
         c.adicionar((String)this.eliminar());
     
     }
     while(!c.esvacia()){
         this.adicionar(c.eliminar());
     }
     for(int i=0;i<n;i++){
         this.adicionar(this.eliminar());
     }
     
 }
 public void paFrontimpbhind(){   
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     while(!this.esVacia()){
         int num=(int)this.eliminar();
         if(num%2!=0){
             this.adicionar(num);
         }else{
             aux.adicionar(num);
         }
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
 }
 boolean esVolcal(char dato){
     dato=Character.toLowerCase(dato);
     return dato=='a'||dato=='e'||dato=='i'||dato=='o'|| dato=='u';
 }
 void eliminarvocales(){
     colascircular aux=new colascircular(100);
     int ne=this.nElem();
     for(int i=0;i<=ne;i++){   
         String ca=(String)this.eliminar();
          String newca="";
          for(int j=0;j<ca.length();j++){
              char caracter=ca.charAt(j);
              if(!esVolcal(caracter)){
                  newca =newca+caracter;
              }
          }
          this.adicionar(newca);
         }
         this.mostrar();
        
            
        
         
    
 }
 double promedioCOLthis(){
     colascircular aux=new colascircular(100);
     double sum=0,numero;
     while(!this.esVacia()){
         numero=(double)this.eliminar();
         sum=sum+numero;
         aux.adicionar(numero);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     return (double)sum/(double)nElem();
 }
 void divirPromedio(){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     double media=this.promedioCOLthis();
     int ne=this.nElem();
     for(int i=0;i<ne;i++){
         double da=(double)this.eliminar();
         if(da<media){
             aux.adicionar(da+"Posicion: "+i);
         }else{if(da>media){
              aux2.adicionar(da+"Posicion: "+i);
         }
            
         }
     }
     System.out.println("MENORES thisL PROMEDIO: ");
     aux.mostrar();
     System.out.println("MthisYORES thisL PROMEDIO: ");
     aux2.mostrar();
 }
 //lenar persona()
 void llenarpersona(){
     System.out.println("CANTIDAD DE ELEMTNOS EN LA COLA:");
     int elen=lee.nextInt();
     for(int j=1;j<=elen;j++){
       System.out.println("nombre:");
        String nombre=lee.next();
        System.out.println("Edad:");
        int edad=lee.nextInt();
        System.out.println("Sexo:");
        String sexo=lee.next();
        int n=2;
        String nee="";
        String ne="";
        for(int i=0;i<2;i++){
             char charac=nombre.charAt(i);
                 ne=ne+charac; 
        }
        String ne2=ne+"00"+j;
        persona p1=new persona(nombre,sexo,ne2,edad);
        this.adicionar(p1);  
     }           
 }
 void llenarHistoria(colascircular cc1){
     //System.out.println("CANTIDAD DE ELEMTNOS EN LA COLA:");
     //int elen=lee.nextInt();
     colascircular aux=new colascircular(100);
     int elen2=cc1.nElem();
    for(int i=1;i<=elen2;i++){    
        //for(int j=1;j<=elen;j++){
            persona p1=new persona();
            p1=(persona)cc1.eliminar();
            p1.toString();
         System.out.println("PACIENTE :"+i);
        //System.out.println("Cigo Paciente: ");
        String codigo=(String)p1.getCodigo();
        String cod_paciente=codigo;
        System.out.println("Trauma:");
        int ctrauma=lee.nextInt();
        System.out.println("Ginecologia:");
        int cginecologia=lee.nextInt();
        System.out.println("Cirugia:");
        int cirugia=lee.nextInt();
        System.out.println("Dermatologia:");
        int cdermatologia=lee.nextInt();
        historia h1=new historia(cod_paciente,cginecologia,cirugia,cdermatologia,ctrauma);
        this.adicionar(h1);
        aux.adicionar(p1);
     }
    while(!aux.esVacia()){
        cc1.adicionar(aux.eliminar());
    }
     }
       
 //}
 void encisoB(){
     
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     int ele=this.nElem();
     int sum=0,c1=0,c2=0,c3=0,c4=0;
     int sum2=0,sum3=0,sum4=0;
     for(int i=1;i<=ele;i++){
        
        historia h1=new historia();
        h1=(historia)this.eliminar();
        if(h1.getCtrauma()>0){
            c1++;
        }
        if(h1.getCginecologia()>0){
            c2++;
        }
        if(h1.getCirugia()>0){
            c3++;
        }
        if(h1.getCdermatologia()>0){
            c4++;
        }
        sum=sum+h1.getCtrauma();
        sum2=sum2+h1.getCginecologia();
        sum3=sum3+h1.getCirugia();
        sum4=sum4+h1.getCdermatologia();
     aux.adicionar(h1);
     }
     System.out.println("-----------------------------------------------------------");
     System.out.println("La cantidad de atentidos en Trauma es de: "+c1+" "+"y su ingreso es de :"+sum);
     System.out.println("La cantidad de atentidos en Ginecologia es de: "+c2+" "+"y su ingreso es de :"+sum2);
     System.out.println("La cantidad de atentidos en Cirugia es de: "+c3+" "+"y su ingreso es de :"+sum3);
     System.out.println("La cantidad de atentidos en Dermatologia es de: "+c4+" "+"y su ingreso es de :"+sum4);
     System.out.println("-----------------------------------------------------------");
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
 }
 void encisoC(){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     int ele=this.nElem();
     int sum=0,c1=0,c2=0,c3=0,c4=0;
     int sum2=0,sum3=0,sum4=0,sum5=0;
     for(int i=1;i<=ele;i++){
        historia h1=new historia();
        h1=(historia)this.eliminar();
        sum=sum+h1.getCtrauma();
        sum2=sum2+h1.getCginecologia();
        sum3=sum3+h1.getCirugia();
        sum4=sum4+h1.getCdermatologia();
     aux.adicionar(h1);
     }
     sum5=sum+sum2+sum3+sum4;
     System.out.println("El total de todas las especialidades es: "+sum5);
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
 }
 void encisoD(){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     int ele=this.nElem();
     int sum=0,c1=0,c2=0,c3=0,c4=0;
     int sum2=0,sum3=0,sum4=0,sum5=0;
     for(int i=1;i<=ele;i++){
        historia h1=new historia();
        h1=(historia)this.eliminar();
        sum=sum+h1.getCtrauma();
        sum2=sum2+h1.getCginecologia();
        sum3=sum3+h1.getCirugia();
        sum4=sum4+h1.getCdermatologia();
     aux.adicionar(h1);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     if(sum>sum2 && sum>sum3 && sum>sum4){
         System.out.println("La especialidad que genera mas es Trauma con ingreso de : "+sum);
     }else{
         
         if(sum2>sum && sum2>sum3 && sum2>sum4){
            System.out.println("La especialidad que genera mas es Ginecologia con ingreso de : "+sum2); 
         }else{   
             if(sum3>sum && sum3>sum2 && sum3>sum4){
                System.out.println("La especialidad que genera mas es Cirugia con ingreso de : "+sum3);   
             }else{

                 if(sum4>sum && sum4>sum2 && sum4>sum3){
                    System.out.println("La especialidad que genera mas es Dermatologia con ingreso de : "+sum4); 
                 }
                     }
         }
     }
 }
 
 
 void encisoE(){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     int ele=this.nElem();
     int sum=0;
     int sum2=0,sum3=0,sum4=0;
     for(int i=1;i<=ele;i++){
        historia h1=new historia();
        h1=(historia)this.eliminar();
        sum=sum+h1.getCtrauma();
        sum2=sum2+h1.getCginecologia();
        sum3=sum3+h1.getCirugia();
        sum4=sum4+h1.getCdermatologia();
     aux.adicionar(h1);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     if(sum<sum2 && sum<sum3 && sum<sum4){
         System.out.println("La especialidad que genera menos es Trauma con ingreso de : "+sum);
     }else{
         if(sum2<sum && sum2<sum3 && sum2<sum4){
            System.out.println("La especialidad que genera menos es Ginecologia con ingreso de : "+sum2); 
         }else{
             if(sum3<sum && sum3<sum2 && sum3<sum4){
                System.out.println("La especialidad que genera menos es Cirugia con ingreso de : "+sum3);   
             }else{
                 if(sum4<sum && sum4<sum2 && sum4<sum3)
                    System.out.println("La especialidad que genera menos es Cirugia con ingreso de : "+sum4); 
                     }
         }
     }
 }
 void encisoF(){
     colascircular aux=new colascircular(100);
     int cf=0,cm=0;
     int nm=this.nElem();
     while(!this.esVacia()){
         persona p1=new persona();
         p1=(persona)this.eliminar();
         String sex=p1.getSexo();
         if(sex.equals("f")){
             cf++;
         }else{
             cm++;
         }
         aux.adicionar(p1);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     System.out.println("La cantidad de mujeres atentidas es: "+cf);
     System.out.println("La cantidad de homres atentidos es: "+cm);
     
 }
 void encisoG(){
     colascircular aux=new colascircular(100);
     int c1=0,c2=0,c3=0,c4=0;
     int nm=this.nElem();
     for(int i=1;i<=nm;i++){
         historia p1=new historia();
         p1=(historia)this.eliminar();
         if(p1.getCtrauma()==0){
             c1++;
         }
         if(p1.getCginecologia()==0){
             c2++;
         }
         if(p1.getCirugia()==0){
             c3++;
         }
         if(p1.getCdermatologia()==0){
             c4++;
         }
         aux.adicionar(p1);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     if(c1>c2 && c1>c2 && c1>c4){
         System.out.println("Trauma tiene menos consultas: "+c1);
     }else{
         if(c2>c1 && c2>c3 && c1>c4){
             System.out.println("Ginecologia tiene menos consultas: "+c2);
         }else{
             if(c3>c1 && c3>c2 && c3>c4){
                 System.out.println("Cirugia tiene menos consultas: "+c3);
             }else{
                if(c4>c1 && c4>c2 && c4>c3){
                    System.out.println("Dermatologia tiene menos consultas: "+c4);
                } 
             }
         }
     }
 }
 
     
     
 }

    

