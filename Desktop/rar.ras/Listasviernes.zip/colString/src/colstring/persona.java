/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colstring;

import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class persona {
    Scanner lee=new Scanner(System.in);
    private String nombre,sexo,codigo;
    private int edad;

    public persona(String nombre, String sexo, String codigo, int edad) {
        this.nombre = nombre;
        this.sexo = sexo;
        this.codigo = codigo;
        this.edad = edad;
    }
    public persona() {
    }
    void leer(){
        System.out.println("nombre:");
        nombre=lee.next();
        System.out.println("Edad:");
        edad=lee.nextInt();
        System.out.println("Sexo:");
        sexo=lee.next();
        
    }

    public String toString(){
        return "nomre: "+nombre+"--edad:"+edad+"--sexo"+sexo+"CodigoParciente:"+codigo;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    
    
}
