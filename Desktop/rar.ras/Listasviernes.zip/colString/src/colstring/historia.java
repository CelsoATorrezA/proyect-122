
package colstring;

import java.util.Scanner;

public class historia {
    Scanner lee=new Scanner(System.in);
    private String cod_paciente;
    private int cginecologia,cirugia,cdermatologia,ctrauma;

    public historia(String cod_paciente, int cginecologia, int cirugia, int cdermatologia, int ctrauma) {
        this.cod_paciente = cod_paciente;
        this.cginecologia = cginecologia;
        this.cirugia = cirugia;
        this.cdermatologia = cdermatologia;
        this.ctrauma = ctrauma;
    }

    public historia() {
    }
    void leer(){
        System.out.println("Cigo Paciente: ");
        cod_paciente=lee.next();
        System.out.println("Trauma:");
        ctrauma=lee.nextInt();
        System.out.println("Ginecologia:");
        cginecologia=lee.nextInt();
        System.out.println("Cirugia:");
        cirugia=lee.nextInt();
        System.out.println("Dermatologia:");
        cdermatologia=lee.nextInt();
    }
    public String toString(){
        return "Codpaciente: "+cod_paciente+"Trauma: "+ctrauma+"Ginecologia:"+cginecologia+
                "Cirugia: "+cirugia+"Dermatologia:"+cdermatologia;
    }

    public String getCod_paciente() {
        return cod_paciente;
    }

    public void setCod_paciente(String cod_paciente) {
        this.cod_paciente = cod_paciente;
    }

    public int getCginecologia() {
        return cginecologia;
    }

    public void setCginecologia(int cginecologia) {
        this.cginecologia = cginecologia;
    }

    public int getCirugia() {
        return cirugia;
    }

    public void setCirugia(int cirugia) {
        this.cirugia = cirugia;
    }

    public int getCdermatologia() {
        return cdermatologia;
    }

    public void setCdermatologia(int cdermatologia) {
        this.cdermatologia = cdermatologia;
    }

    public int getCtrauma() {
        return ctrauma;
    }

    public void setCtrauma(int ctrauma) {
        this.ctrauma = ctrauma;
    }
    
    
    
}
