
package newpila;

import java.util.Scanner;
public class NewPila {

    public static void main(String[] args) {
        Scanner lee=new Scanner(System.in);
        pilaCadena a=new pilaCadena(100);
        pila x=new pila(100);      
        pila x2=new pila(100); 
        pila x3=new pila(200);
         int ele=0;
         System.out.println("Ingrese canditada de la pila A");
        int n=lee.nextInt();
        for(int i=0;i<n;i++){
          System.out.println("DATO : "+(i+1)+" DE LA PILA A");
          int ele1=lee.nextInt();
            x.adicionar(ele1);}
        System.out.println("VARIANZA: ");
        System.out.println(x.varianza());
        System.out.println("PROMEDIO: ");
        System.out.println(x.promedioPila());
        System.out.println("DESVIACION ESTANDAR: ");
        System.out.println(x.DesviacionEstandar());
        System.out.println("MEDIA ARMONICA: ");
        System.out.println(x.mediaArmonica());
        System.out.println("MEDIA GEOMETRICA: ");
        System.out.println(x.MediaGeometrica());
        System.out.println("ORDENAS DE FORMA ASCENDENTE: ");
        x.ordenarAsc();
        x.mostrar();
        System.out.println("ORDENAR ABAJO Y ARRIBA");
        x.ImpareFdesc();
        /*System.out.println("Cantidad de elementos de la pila String:");
         int ns=lee.nextInt();
         for(int i=1;i<=ns;i++){
             System.out.println("DAtO: "+i);
             String dato=lee.next();
             a.adicionar(dato);
         }
         System.out.println("Pila cadena: ");
         a.mostrar();
         System.out.println("INVERTIR CADENA: ");
         a.voltearCadenaString();
         a.mostrar();
         System.out.println("mayusculas");
         a.ConvertirMayus();
         a.mostrar();
         
        
        System.out.println("Ingrese canditada de la pila B");
        int n2=lee.nextInt();
        for(int i=0;i<n2;i++){
          System.out.println("DATO : "+(i+1)+" DE LA PILA B");
          int ele1=lee.nextInt();
            x2.adicionar(ele1);
        }*/
        /*System.out.println("Ingrese canditada de la pila B");
        int n2=lee.nextInt();
        for(int i=0;i<n2;i++){
          System.out.println("DATO : "+(i+1)+" DE LA PILA B");
          int ele1=lee.nextInt();
            x.adicionar(ele1);
        }
        x.mostrar();
        System.out.println("pila ordenada::");
        x.ImpareFdesc();
        System.out.println("-----PILA ORIGNAL A-----");
        x.mostrar();
        System.out.println("ENCISO A LLEVAR EL ULTIMO AL INICIO INGRESE CUANTAS VECES QUIERE ROTAR: ");
        int nv=lee.nextInt();
        x.llevarUltimo(nv);
        System.out.println("PILA  ORIGINAL PARES: ");
        x2.mostrar();
        System.out.println("ROTACION DE LOS PARES INGRES CUANTAS VECES QUIERE ROTAR: ");
        int nv1=lee.nextInt();
        x2.rotarPares(nv1);*/
        //System.out.println("AÑADIR LAS RESTAS:  ");
        //x3.restar();
        /*System.out.println("ORDENAMIENTO:");
        x3.ordenarAsc();
        x3.mostrar();
        System.out.println("ORDENAMIENTO 2 : ");
        x3.ordenarDesc();
        x3.mostrar();*/
        
    }
    
}
