
package newpila;

import java.util.HashSet;

public class pila {
    private int tope,max;
    int v[]=new int[100]; 
    
    public pila(int cp){
        tope=0;
        max=cp;
}
    public void mostrar(){
        int elem;
        pila aux=new pila(max);
        
        while(!esVacia()){
            elem=eliminar();
            System.out.println(elem);
            aux.adicionar(elem);
        }
        while(!aux.esVacia()){
            adicionar(aux.eliminar());
        }
        
    }
    int nElem(){
        return tope;
    }
    int eliminar(){
        int dato=0;
        if(esVacia()){
            System.out.println("Pila vacia");
        }
        else{
            dato=v[tope];
            tope=tope-1;
        }
        return dato;
    }
    public void adicionar(int ele){
        if(!esLlena()){
            tope=tope+1;
            v[tope]=ele;
        }
        else{
            System.out.println("PIla llena");
    }
    }
    boolean esLlena(){
        if(tope==max){
            return true;
        }else{
            return false;
        }
        
    }
    boolean esVacia(){
        if(tope==0){
            return true;
        }else{
            return false;
        }
        
    }
    //Maximo de la Pila
    int maximoPila(){
        pila aux=new pila(max);
        int maximo=-10,numero;
        while(!esVacia()){
            numero=eliminar();
            if(maximo<numero){
                maximo=numero;
            }
            aux.adicionar(numero);
    }
        //vaciando del aux ala pilaprincipal
        while(!aux.esVacia()){
           adicionar(aux.eliminar());
        }
        return maximo;
    }
    //media armonica
    double mediaArmonica(){
        pila aux=new pila(100);
        double sumaReciprocos=0;
        int n=0;
        while(!this.esVacia()){
            int elemento=this.eliminar();
            sumaReciprocos +=(1.0/elemento);
            n++;
            aux.adicionar(elemento);
        }
        while(!aux.esVacia()){
            adicionar(aux.eliminar());
        }
        double Armonica=n/sumaReciprocos;
        return Armonica;
    }
    //promedio de la pila
    double promedioPila(){
        pila aux=new pila(max);
        int sum=0,numero;
        while(!esVacia()){
            numero=this.eliminar();
            sum=sum+numero;
            aux.adicionar(numero);
        }
        while(!aux.esVacia()){
            adicionar(aux.eliminar());
        }
        return (double)sum/(double)nElem();
    }
    //calcular la mediaEstandar
    double DesviacionEstandar(){
        pila aux=new pila(100);
        double media=this.promedioPila();
        double sumaCuadraos=0;
        while(!this.esVacia()){
            int elemen=this.eliminar();
            double difencia=elemen-media;
            sumaCuadraos +=Math.pow(difencia, 2);
            aux.adicionar(elemen);
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        double varianza =sumaCuadraos/this.nElem();
        double desviacion=Math.sqrt(varianza);
      
        return desviacion;
    }
    //calcular la Varianza
    double varianza(){
        int mn=this.nElem();
        double media=this.promedioPila();
        pila aux=new pila(100);
        double sumaCuadrados=0;
        while(!this.esVacia()){
            int elem=this.eliminar();
            double diferencia=elem-media;
            sumaCuadrados += diferencia*diferencia;
            aux.adicionar(elem);
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        double varianza =sumaCuadrados/mn;
        return varianza;
    }
    //media geometrica
    double MediaGeometrica(){
        pila aux=new pila(100);
    double producto=1;
    int n=0;
    while(!this.esVacia()){
        int elemento=this.eliminar();
        producto *= elemento;
        n++;
        aux.adicionar(elemento);
    }
    while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
    double mediaGeometria=Math.pow(producto, 1.0/n);
    return mediaGeometria;
    }
    
    //invertir N veces
    void invertirpila(int n){
        pila aux1=new pila(100);
        pila aux2=new pila(100);
        
        for(int i=1;i<=n;i++){
            System.out.println("INVERSION NUMERO: "+i);
        //primer vaci de pila origin a aux1
        while(!this.esVacia()){
            aux1.adicionar(this.eliminar());
        }
        while(!aux1.esVacia()){
            aux2.adicionar(aux1.eliminar());
        }
        //tercer vacaido de aux2 a origin
        while(!aux2.esVacia()){
            this.adicionar(aux2.eliminar());
        }
        
        this.mostrar();
            
        }

        
        
    }
    //inver tir pila
    void invertir(){
        pila a=new pila(100);
        pila b=new pila(100);
        while(!esVacia()){
            a.adicionar(eliminar());
        }
        while(!a.esVacia()){
            b.adicionar(a.eliminar());
        }
        while(!b.esVacia()){
            adicionar(b.eliminar());
        }
        
        
    }
    pila invertiPilas(int n2){
        pila aux1=new pila(100);
        pila aux2=new pila(100);
        pila a=new pila(100);
       int n=nElem();
       while(!esVacia()){
           a.adicionar(eliminar());
       } 
       for(int j=1;j<=n2;j++){
          for(int i=1;i<=n;i++){
              
           int dato=this.eliminar();
           aux1.adicionar(dato);
           aux2.adicionar(dato);
       }
        aux1.mostrar();
       while(!aux1.esVacia()){
           a.adicionar(aux1.eliminar());
       } 
       a.invertir();
      
       }
       aux2.invertir();
       while(!aux2.esVacia()){
           this.adicionar(aux2.eliminar());
       }
       return aux2;       
    }
    void eliminarRep(){
       System.out.println("Pila sin números repetidos:");
    HashSet<Integer> elementos = new HashSet<>();
    pila aux = new pila(100);
    int num;

    // Vaciar v a aux en orden inverso y eliminar números repetidos
    while (!this.esVacia()) {
        num = eliminar();
        if (!elementos.contains(num)) {
            elementos.add(num);
            aux.adicionar(num);
        }
    }
    // Vaciar aux a v en orden original y mostrar los elementos
    while (!aux.esVacia()) {
        num = aux.eliminar();
        this.adicionar(num);
        System.out.println(num);
    }
    System.out.println("-----------");      
    }
    void llevarUltimo(int nv){
        int numero=0;
        pila aux=new pila(100);
        for(int i=0;i<nv;i++){
           while(!this.esVacia()){
           int nu=this.eliminar();
           if(this.tope!=0){
               aux.adicionar(nu);
           }else{
               numero=nu;
           }
       }
       while(!aux.esVacia()){
           this.adicionar(aux.eliminar());
       }
       this.adicionar(numero);
            System.out.println("LLEVADO DE PILA : "+i);
       
            this.mostrar();
    }}
    void rotarPares(int nm){
        pila aux=new pila(100);
        pila auxImpares=new pila(100);
        pila auxPares=new pila(100);
        int elen=nElem();
        for(int i=0;i<nm;i++){         
          boolean ban=true;
          int ele,num=0;
          while(!this.esVacia()){
              ele=this.eliminar();
              if((ele%2==0) && ban==true){
                  num=ele;
                  ban=false;
              }
              aux.adicionar(ele);
          }
          while(!aux.esVacia()){
              ele=aux.eliminar();
              if(ele%2==0){
                  this.adicionar(num);
                  num=ele;
              }else{
                  this.adicionar(ele);
              }
          }
          System.out.println("----PARES INVERTIDOS----"+i);
          this.mostrar();
        }  
        }
    void restar(){
        int dato=0;
        pila aux=new pila(100);
        while(!this.esVacia()){
             dato=this.eliminar();
             int ban=dato-1;
             while(ban!=0){
                 aux.adicionar(ban);
                 ban--;
             }
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        this.invertir();
        this.adicionar(0);
        this.mostrar(); 
    }
    //ordenar ascendentement
    void ordenarAsc(){
          pila auxPila = new pila(100);
        while (!esVacia()) {
            int elemento = eliminar();
            while (!auxPila.esVacia() && auxPila.elementoTope() < elemento) {
                adicionar(auxPila.eliminar());
            }
            auxPila.adicionar(elemento);
        }
        while (!auxPila.esVacia()) {
            adicionar(auxPila.eliminar());
        }
    }
    //ordenar decendentemente
    void ordenarDesc(){
          pila auxPila = new pila(100);
        while (!esVacia()) {
            int elemento = eliminar();
            while (!auxPila.esVacia() && auxPila.elementoTope() > elemento) {
                adicionar(auxPila.eliminar());
            }
            auxPila.adicionar(elemento);
        }
        while (!auxPila.esVacia()) {
            adicionar(auxPila.eliminar());
        }
    }    
    public int elementoTope() {
        if (tope >= 0) {
            return v[tope];
        } else {
            throw new IllegalStateException("La pila está vacía");
        }
    }
    //Ordenas impares de forma descendente,manteniendo el orden delos elementos
    void ImpareFdesc(){
        pila aux=new pila(100);
        pila aux2=new pila(100);
        pila aux3=new pila(100);
        while(!this.esVacia()){
            int elem=this.eliminar();
            if(elem%2==0){
                aux.adicionar(elem);
            }else{
                aux2.adicionar(elem);
            }
        }
        while(!aux.esVacia()){
           aux3.adicionar(aux.eliminar());
        }
        while(!aux2.esVacia()){
            aux3.adicionar(aux2.eliminar());
        }
        while(!aux3.esVacia()){
            this.adicionar(aux3.eliminar());
        }
        this.mostrar();
    }
       
        
        
        
     
    
    
}

