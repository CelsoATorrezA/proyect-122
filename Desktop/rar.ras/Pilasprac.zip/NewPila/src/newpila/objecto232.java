/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpila;

/**
 *
 * @author Celso Torrez
 */
public class objecto232 {
    private String nombre_libro,colorportada;
    private int cantidaPaginas;

    public objecto232(String nombre_libro, String colorportada, int cantidaPaginas) {
        this.nombre_libro = nombre_libro;
        this.colorportada = colorportada;
        this.cantidaPaginas = cantidaPaginas;
    }

    public objecto232() {
    }
    public String getNombre_libro() {
        return nombre_libro;
    }
    public void setNombre_libro(String nombre_libro) {
        this.nombre_libro = nombre_libro;
    }
    public String getColorportada() {
        return colorportada;
    }
    public void setColorportada(String colorportada) {
        this.colorportada = colorportada;
    }
    public int getCantidaPaginas() {
        return cantidaPaginas;
    }
    public void setCantidaPaginas(int cantidaPaginas) {
        this.cantidaPaginas = cantidaPaginas;
    }
    
}
