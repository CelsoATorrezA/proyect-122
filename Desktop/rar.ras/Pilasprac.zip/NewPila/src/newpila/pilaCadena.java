
package newpila;

import java.util.Scanner;

public class pilaCadena {
    Scanner lee=new Scanner(System.in);
    private int tope,max;
    String v[]=new String[100]; 
    
    public pilaCadena(int cp){
        tope=0;
        max=cp;
}
    public void mostrar(){
        String elem;
        pilaCadena aux=new pilaCadena(max);
        while(!esVacia()){
            aux.adicionar(eliminar());
        }
        while(!aux.esVacia()){
            elem=aux.eliminar();
            System.out.println(elem);
            adicionar(elem);
        }
    }
    int nElem(){
        return tope;
    }
   String eliminar(){
        String dato=" ";
        if(esVacia()){
            System.out.println("Pila vacia");
        }
        else{
            dato=v[tope];
            tope=tope-1;
        }
        return dato;
    }
    public void adicionar(String ele){
        if(!esLlena()){
            tope=tope+1;
            v[tope]=ele;
        }
        else{
            System.out.println("PIla llena");
    }
    }
    boolean esLlena(){
        if(tope==max){
            return true;
        }else{
            return false;
        }
        
    }
    boolean esVacia(){
        if(tope==0){
            return true;
        }else{
            return false;
        }
        
    }
    /*int maximoPila(){
        pila aux=new pila(max);
        int maximo=-10,numero;
        while(!esVacia()){
            numero=eliminar();
            if(maximo<numero){
                maximo=numero;
            }
            aux.adicionar(numero);
    }
        //vaciando del aux ala pilaprincipal
        while(!aux.esVacia()){
           adicionar(aux.eliminar());
        }
        return maximo;
    }
    double promedioPila(){
        pila aux=new pila(max);
        int sum=0,numero;
        while(!esVacia()){
            numero=this.eliminar();
            sum=sum+numero;
            aux.adicionar(numero);
        }
        while(!aux.esVacia()){
            adicionar(aux.eliminar());
        }
        return (double)sum/(double)nElem();
    }*/

    
    
    void invertirpila(int n){
        pilaCadena aux1=new pilaCadena(100);
        pilaCadena aux2=new pilaCadena(100);
        
        for(int i=1;i<=n;i++){
            System.out.println("INVERSION NUMERO: "+i);
        //primer vaci de pila origin a aux1
        while(!this.esVacia()){
            aux1.adicionar(this.eliminar());
        }
        while(!aux1.esVacia()){
            aux2.adicionar(aux1.eliminar());
        }
        //tercer vacaido de aux2 a origin
        while(!aux2.esVacia()){
            this.adicionar(aux2.eliminar());
        }
        
        this.mostrar();
            
        }      
    }
    int contarVocales(String cad){
        int cont=0;
        char car = 0;
        for(int i=0;i<cad.length();i++){
            car=cad.charAt(i);
            switch(car){
                case 'a': cont++; break;
                case 'e': cont++; break;
                case 'i': cont++; break;
                case 'o': cont++; break;
                case 'u': cont++; break;
            }
        }
        return cont;
    }
    
    void contar(){
        pilaCadena aux=new pilaCadena(100);
        pila n=new pila(100);
        while(!this.esVacia()){
            String dato=this.eliminar();
            System.out.println(dato+" "+"tiene vocales:  "+contarVocales(dato));
            aux.adicionar(dato);
            n.adicionar(contarVocales(dato));
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        //n.invertir();
        n.mostrar();
    }
    //invertir las cadenas de la pila
    void voltearCadenaString(){
        pilaCadena aux=new pilaCadena(100);
        while(!this.esVacia()){
            String ca=this.eliminar();
            char[] caracters=ca.toCharArray();
            int ini=0;
            int fin=caracters.length-1;
            while(ini<fin){
                char temp=caracters[ini];
                caracters[ini]=caracters[fin];
                caracters[fin]=temp;
                ini++;
                fin--;
            }
            String inCA=new String (caracters);
            aux.adicionar(inCA); 
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
    }
    //convertir todas las cadenas en mayusculas:
    void ConvertirMayus(){
        pilaCadena aux=new pilaCadena(100);
        while(!this.esVacia()){
            String ca=this.eliminar();
            String mca=ca.toUpperCase();
            aux.adicionar(mca);
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
    }
    //validar correo
   boolean validaCror(){
        while(!this.esVacia()){
            String correo=this.eliminar();
            boolean arroba=false;
            boolean punto=false;
            
            char[] caracteres=correo.toCharArray();
            for(int i=0;i<caracteres.length;i++){
                if(caracteres[i]=='@' && !arroba){
                    arroba=true;
                }else{
                    if(caracteres[i]=='.'&& arroba &&!punto){
                        punto=true;
                    }else{
                        if(caracteres[i]=='@' || (caracteres[i]=='.'&& arroba)){
                            return false;    
                        }
                    }
                }                
            }
            if(arroba && punto){
                continue;
            }else{
                return false;
            }
        }
        return true;
    }
  //devolver la posicion de  de la pila
   void devolver(){
       System.out.println("Introduza la cadena que quiere buscar");
       String cad=lee.next();
       pilaCadena aux=new pilaCadena(100);
       int ne=this.nElem();
       for(int i=0;i<ne;i++){
           String dao=this.eliminar();
           if(dao.equals(cad)){
               System.out.println("LA POSCION ES: "+i);
           }
           aux.adicionar(dao);
       }
       while(!aux.esVacia()){
           this.adicionar(aux.eliminar());
       }
   }
   
   
}
