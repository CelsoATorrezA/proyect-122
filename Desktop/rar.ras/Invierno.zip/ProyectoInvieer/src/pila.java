
public class pila {
    private int tope,max;
    Object v[]=new Object[100]; 
    
    public pila(int cp){
        tope=0;
        max=cp;
}
    public void mostrar(){
        Object elem;
        pila aux=new pila(max);
        while(!esVacia()){
            aux.adicionar(eliminar());
        }
        while(!aux.esVacia()){
            elem=aux.eliminar();
            System.out.println(elem);
            adicionar(elem);
        }
    }
    int nElem(){
        return tope;
    }
    Object eliminar(){
        Object dato=null;
        if(esVacia()){
            System.out.println("Pila vacia");
        }
        else{
            dato=v[tope];
            tope=tope-1;
        }
        return dato;
    }
    public void adicionar(Object ele){
        if(!esLlena()){
            tope++;     //v[tope+1]=elem
	    v [tope] = ele;  //tope++
        }
        else{
            System.out.println("PIla llena");
    }
    }
    boolean esLlena(){
        if(tope==max){
            return true;
        }else{
            return false;
        }
        
    }
    boolean esVacia(){
        if(tope==0){
            return true;
        }else{
            return false;
        }
        
    }
        void invertir(){
        pila a=new pila(100);
        pila b=new pila(100);
        while(!esVacia()){
            a.adicionar(eliminar());
        }
        while(!a.esVacia()){
            b.adicionar(a.eliminar());
        }
        while(!b.esVacia()){
            adicionar(b.eliminar());
        }
    }
}
