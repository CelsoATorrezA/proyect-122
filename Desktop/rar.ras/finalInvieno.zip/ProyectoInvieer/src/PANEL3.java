
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Celso Torrez
 */
public class PANEL3 extends javax.swing.JFrame {
    DefaultTableModel n=new DefaultTableModel();
 
    pila p2=new pila(100);
    pila aux=new pila(100);
    public PANEL3() {
        initComponents();
        n.addColumn("DEPARTAMENTO");
        n.addColumn("FARMACIAS");
        n.addColumn("HABITANTES");
        this.Tabla.setModel(n);
    }
    public void getPila(pila p){
        this.p2=p;
    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttoeliminar2 = new javax.swing.JButton();
        campoeliminar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        buttonbuscar = new javax.swing.JButton();
        campobuscar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttoeliminar2.setText("ELIMINAR");
        buttoeliminar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttoeliminar2ActionPerformed(evt);
            }
        });
        getContentPane().add(buttoeliminar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(425, 133, 110, 50));

        campoeliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoeliminarActionPerformed(evt);
            }
        });
        getContentPane().add(campoeliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 150, 40));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("DEPARTAMENTO QUE DESEA ELIMINAR: ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 240, 60));

        jButton1.setText("volver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 503, 100, 50));

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "DEPARTAMENTO", "FARMACIAS", "HABITANTES"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, -1, 150));

        buttonbuscar.setText("BUSCAR");
        buttonbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonbuscarActionPerformed(evt);
            }
        });
        getContentPane().add(buttonbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 30, 110, 50));
        getContentPane().add(campobuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 30, 150, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Verificar si Existe el Departamento: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 230, 60));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 560));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonbuscarActionPerformed
      Principal1 p1=new Principal1();
        String nombre=campobuscar.getText();
      int  ban=0;
      while(!p2.esVacia()){
          ciudad c=new ciudad();
          c=(ciudad)p2.eliminar();
          System.out.println(c.toString());
          if(nombre.equals(c.getNombre())){
              ban=1;
              
          }
          aux.adicionar(c);
      }
      if(ban==1){
          JOptionPane.showMessageDialog(null, "El departamento si esta registrado!");
      }else{
          JOptionPane.showMessageDialog(null, "El departamento no esta registrado!");
      }
       while(!aux.esVacia()){
          p2.adicionar(aux.eliminar());
      }
      
     
     
      campobuscar.setText("");  
      llenarJtable(p2);
       p1.getPila(p2);
    }//GEN-LAST:event_buttonbuscarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void campoeliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoeliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoeliminarActionPerformed

    private void buttoeliminar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttoeliminar2ActionPerformed
         Principal1 p1=new Principal1();
        String eliminar=campoeliminar.getText();
        while(!p2.esVacia()){
          ciudad c=new ciudad();
          c=(ciudad)p2.eliminar();
          System.out.println(c.toString());
          if(!eliminar.equals(c.getNombre())){
              aux.adicionar(c); 
          }
      }
         while(!aux.esVacia()){
          p2.adicionar(aux.eliminar());
      }
        JOptionPane.showMessageDialog(null, "El departamento HA SIDO ELIMINADO!");
      campoeliminar.setText("");  
      llenarJtable(p2);
       p1.getPila(p2);
    }//GEN-LAST:event_buttoeliminar2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PANEL3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PANEL3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PANEL3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PANEL3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PANEL3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton buttoeliminar2;
    private javax.swing.JButton buttonbuscar;
    private javax.swing.JTextField campobuscar;
    private javax.swing.JTextField campoeliminar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
 void borrartabla(){
     DefaultTableModel modelo=(DefaultTableModel)Tabla.getModel();
     while(modelo.getRowCount()>0)modelo.removeRow(0);
 } 
    public void llenarJtable(pila p){
      pila aux=new pila(100);
      borrartabla();
      DefaultTableModel modelo = (DefaultTableModel) Tabla.getModel();
      while (!p.esVacia() ){
         Object fila[]=new Object[3];
         ciudad c=new ciudad();
         c=(ciudad)p.eliminar();
         fila[0]=c.getNombre();
         fila[1]=c.getCanFarmacia();
         fila[2]=c.getCantHabitantes();
         modelo.addRow(fila);
         aux.adicionar(c);
      }
      Tabla.setModel(modelo);
      while(!aux.esVacia()){
          p.adicionar(aux.eliminar());
      }
    }
 
}
