


public class LSNormal extends LSimple1 {
LSNormal()
{
super();
}
boolean esVacia()
{
return(super.esVacia());
}
NodoS getCabecera()
{
return p;
}
void setCabecera(NodoS q)
{p=q;}
void adiFin(Object da)
{
NodoS x,u;
x=new NodoS();
x.setDato(da);
if (esVacia()) p=x;
else {u=p;
 while(u.getSig()!=null)
 u=u.getSig();
 u.setSig(x);
} 
}
void adiPrimero(Object da)
{ NodoS y;
y=new NodoS(); 
y.setDato(da);
y.setSig(p);
p=y;
}
Object eliFin()
{
NodoS au=null,y,u;
Object Da=null;
if(esVacia()) System.out.println("Lista vacia");
else {u=p;
 while(u.getSig()!=null)
 {au=u;
 u=u.getSig();
 }
 Da=u.getDato();
 if(p==u) p=null;
 else au.setSig(null);
}
return Da;
}
int nElem()
{
 NodoS x;int cont;
if (esVacia()) cont=0;
else {
 x=p;cont=1;
 while (x.getSig()!= null)
{
 cont++;
 x=x.getSig();
 } 
}
return cont;
}
Object eliPrimero()
{
Object da=null;
if (!esVacia()){
da=p.getDato();
p=p.getSig();
}
else System.out.println("Lista vacia...");
return da;
}
void mostrar()
{NodoS y;
if (esVacia()) System.out.println("Lista vacia");
else {y=p;
 while(y!=null)
 {System.out.print("\t"+y.getDato());
 y=y.getSig();
 }
 }
}
}

