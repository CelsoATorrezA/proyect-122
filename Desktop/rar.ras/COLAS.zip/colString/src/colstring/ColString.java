/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colstring;

import java.util.Scanner;

/**
 *
 * @author Celso Torrez
 */
public class ColString {

    public static void main(String[] args) {
        Scanner lee=new Scanner(System.in);
        /*CSNormal a=new CSNormal(100);
        CSNormal b=new CSNormal(100);
        System.out.println("Cantidad de elemento de la COLA INTS: ");
        int n=lee.nextInt();
        for(int i=1;i<=n;i++){
            System.out.println("DATO: "+i);
            Object dato=lee.nextInt();
            a.adicionar(dato);
        }
        System.out.println("Cantidad de elemento de la COLA STRINGS: ");
        int n2=lee.nextInt();
        for(int i=1;i<=n2;i++){
            System.out.println("DATO: "+i);
            Object dato=lee.next();
            b.adicionar(dato);
        }
        System.out.println("\n COLA ORIGINAL:");
        a.mostrar();
        System.out.println("\n MAXIMO NUMERO: ");
        System.out.println(a.MaximoCola());
        System.out.println("\n PROMEDIO COLA");
        System.out.println(a.promedioCOLA());
        System.out.println("\n  COLA INVERTIDA");
        a.invertir();
        a.mostrar();
        System.out.println("\n ORDENAR LA COLA: ");
        a.ordenarASC();
        a.mostrar();
        b.mostrar();
        System.out.println("\n MAYUSCULA: ");
        b.MayusculaPrimera();
        System.out.println("INTERCAMBIAR LETRAS: ");
        b.intercambiar(a);*/
        //COLAS CIRCUlARESSSSSSSS
        
        colascircular c1=new colascircular(100);
        colascircular c2=new colascircular(100);
        
        c1.llenarString();
        c2.llenarString();
        System.out.println("COLA CSCIRCULA RESULTANTE 1: ");
        c1.mostrar();
        System.out.println("ORDENA cola 2 ");
        c2.mostrar();
        //c1.OrdenarAscendentemente();
        //c1.mostrar();
        //c1.polinomio();
        //System.out.println("Intercalar colas: ");
        //c1.intercalar(c2);
        System.out.println("intercambiar:::::::");
        c1.intercambiarIyJ(c2);
        System.out.println("C1:");
        c1.mostrar();
        System.out.println("C2:");
        c2.mostrar();
        System.out.println("inviritendo::");
        c1.invertir();
    }
    
}
