
package colstring;

import java.util.Scanner;

public class colascircular extends colaimple{
    Scanner lee=new Scanner(System.in);
    colascircular(int m){
        super(m);
    }
    boolean esVacia(){
        if(nElem()==0){
            return true;
        }
        else{
            return false;
        }
    }
    boolean esLlena(){
        if(nElem()==max-1){
            return true;
        }
        else{
            return false;
        }
    }
    void adicionar(Object x){
        if(!esLlena()){
            fin=(fin+1)%max;
            v[fin]=x;
        }
        else{
            System.out.println("cola llena");
        }
    }
    Object eliminar(){
        Object ele=null;
        if(!esVacia()){
            ini=(ini+1)%max;
            ele=v[ini];
        }
        else{
            System.out.println("cola vacia");
        }
        return ele;
    }
    void mostrar(){
        Object ele;
        int n=nElem();
        for(int i=1;i<=n;i++){
            ele=eliminar();
            System.out.println(ele);
            adicionar(ele);
        }
    }
    int nElem(){
        return ((fin-ini+max)%max);
    }
    public Object frente() {
    if (esVacia()) {
        System.out.println("La cola circular está vacía");
        return null;
    }
    
    return v[ini];
}
    //ordenar forma Ascende  y descenden las colas ciruclares

void OrdenarAscendentemente() {
        colascircular aux = new colascircular(100);
        
        while (!this.esVacia()) {
            
            int nroEle = (int)this.nElem();
            int min = numMinColCir(this);
            
            for (int i = 0; i < nroEle; i++) {
                int numero = (int)this.eliminar();
                if(numero == min){
                    aux.adicionar(numero);
                }else{
                    this.adicionar(numero);
                }  
            }
            
        }
        while(!aux.esVacia()){
            this.adicionar(aux.eliminar());
        }
        
        this.mostrar();
    }
int numMinColCir(colascircular a){
    int min=0;
        colascircular aux = new colascircular(100);
         min = (int)a.eliminar();
        a.adicionar(min);
        while (!a.esVacia()) {            
            int num = (int)a.eliminar();
            if(num< min){
                min = num;
            }
            aux.adicionar(num);
        }
        while(!aux.esVacia()){
            a.adicionar(aux.eliminar());
        }
        return min;    
}

    //llenar datos
    void llenar(){
        System.out.println("Numero de elementos de la cola: ");
        int cd=lee.nextInt();
        for(int i=0;i<cd;i++){
            System.out.println("DATO: "+(i+1));
            int da=(int)lee.nextInt();
            this.adicionar(da);
        }
    }
    //llenar datos
    void llenarString(){
        System.out.println("Numero de elementos de la cola: ");
        int cd=lee.nextInt();
        for(int i=0;i<cd;i++){
            System.out.println("DATO: "+(i+1));
            String da=(String)lee.next();
            this.adicionar(da);
        }
    }
    //Polinomio de grado N
    void polinomio(){
        
        colascircular exponente=new colascircular(100);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el grado del polinomio: ");
        int grado = scanner.nextInt();
        
        //pedir coeficientes y exponentes del polinomio
        for(int i=0;i<=grado;i++){
            System.out.println("Ingrese el coeficiente para x^"+i+":");
            int coeficiente=scanner.nextInt();
            this.adicionar(coeficiente);
            exponente.adicionar(i);
        }
        //pedir el numero para evaluar el polinomio
        System.out.println("Ingrese un numero para evaluar el polinomio: ");
        int numero=scanner.nextInt();
        //evaluar el polonimo
        int resultado =evaluarPolinomio(this,exponente,numero);
        //Imprimir el resultado
        System.out.println("El resultado de evaluar el polinomio es: "+resultado);
    }
  int evaluarPolinomio(colascircular coeficientes, colascircular exponentes, int numero) {
        int resultado = 0;
        int n = coeficientes.nElem();

        for (int i = 0; i < n; i++) {
            int coeficiente = (int) coeficientes.eliminar();
            int exponente = (int) exponentes.eliminar();

            resultado += coeficiente * Math.pow(numero, exponente);

            coeficientes.adicionar(coeficiente);
            exponentes.adicionar(exponente);
        }

        return resultado;
    }
  //invertir  C DE CADENAS
   void invertir(){  
     pila aux=new pila(100);
     
     while(!this.esVacia()){
         aux.adicionar((int)this.eliminar());
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     
 }
// inter cambiar sin perder datos es el C DE CCC ENTEROS 
 void intercalar(colascircular c){
     colascircular aux=new colascircular(100);
     colascircular aux2=new colascircular(100);
     colascircular aux3=new colascircular(100);

     while(!this.esVacia() || !c.esVacia()){
         int num1=(int)this.eliminar();
         int num2=(int)c.eliminar();
         int m1=num1, m2=num2;
         aux2.adicionar(m1);
         aux2.adicionar(m2);
         
         aux.adicionar(num1);
         aux3.adicionar(num2);
     }
     while(!aux.esVacia()){
         this.adicionar(aux.eliminar());
     }
     while(!aux3.esVacia()){
         c.adicionar(aux3.eliminar());
     }
     aux2.mostrar();
 }
 //Intercalar i-esimo daot con j.esmio dato
 void intercambiarIyJ(colascircular c){
     System.out.println("INTRODUZCA I-ESIMO: ");
     int ii=lee.nextInt();
     System.out.println("INTRODUZCA j-ESIMO: ");
     int jj=lee.nextInt();
     colascircular aux=new colascircular(100);
     String elementoMi="";
     for(int i=0;i<this.nElem();i++){
         String elemento=(String)this.eliminar();
         if(i==ii){
             elementoMi=elemento;
         }
         this.adicionar(elemento);
     }
     String elementoCj="";
     for(int i=0;i<c.nElem();i++){
         String elemento=(String)c.eliminar();
         if(i==jj){
             elementoCj=elemento;
         }
         c.adicionar(elemento);
     }
     for (int k = 0; k < this.nElem(); k++) {
            String elemento = (String) this.eliminar();
            if (k == ii) {
                this.adicionar(elementoCj);
            } else {
                this.adicionar(elemento);
            }
        }
     for (int k = 0; k < c.nElem(); k++) {
            String elemento = (String) c.eliminar();
            if (k == jj) {
                c.adicionar(elementoMi);
            } else {
                c.adicionar(elemento);
            }
        }
 }
 //inverti k elementos()
 void invertirKelem(){
     pila c=new pila(100);
     System.out.println("Introduzca K: ");
     int k=lee.nextInt();
     int n=this.nElem();
     for(int i=0;i<k;i++){
         c.adicionar((String)this.eliminar());
     
     }
     while(!c.esvacia()){
         this.adicionar(c.eliminar());
     }
     for(int i=0;i<n;i++){
         this.adicionar(this.eliminar());
     }
     
 }
  }
    

