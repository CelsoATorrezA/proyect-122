


public abstract class LSimple1 {
protected NodoS p;
LSimple1()
{p=null;}
 boolean esVacia()
{if (p==null) return true;
else return false;
}
abstract int nElem();
abstract void adiFin(Object dato);
abstract void adiPrimero(Object dato);
//abstract void adiDespuesKnodo(int k,Object da);
//abstract void adiAntesKnodo(int k,Object da);
abstract Object eliFin();
abstract Object eliPrimero();
//abstract Object eliKesinodo(int k);
abstract void mostrar();
}
