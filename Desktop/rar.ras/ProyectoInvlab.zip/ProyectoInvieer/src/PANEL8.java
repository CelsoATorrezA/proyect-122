
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Celso Torrez
 */
public class PANEL8 extends javax.swing.JFrame {

     DefaultTableModel n=new DefaultTableModel();
        pila aux=new pila(100);
       pila pc=new pila(100);
       CSNormal c=new CSNormal(100);
       CSNormal auxc=new CSNormal(100);
    public PANEL8() {
        initComponents();
          n.addColumn("NOMBRE");
        n.addColumn("UBICACION");
        n.addColumn("CLIENTES");
        this.Tabla.setModel(n);
    }
     public void getPila(pila p){
        this.pc=p;
    }
public void getCola(CSNormal c){
    this.c=c;
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        buttonbuscar = new javax.swing.JButton();
        campobuscar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("DESPLEGAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 290, 60));

        buttonbuscar.setText("BUSCAR");
        buttonbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonbuscarActionPerformed(evt);
            }
        });
        getContentPane().add(buttonbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 110, 40));

        campobuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campobuscarActionPerformed(evt);
            }
        });
        getContentPane().add(campobuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 130, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Verificar si Existe farmmacias en la ciudad: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 270, 60));

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "nombre", "FARMACIAS", "HABITANTES"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, 150));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 560));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonbuscarActionPerformed
        Principal1 p1=new Principal1();
        int num=0;
        String nombre=campobuscar.getText();
        int  ban=0;
        while(!pc.esVacia()){
           ciudad c=new ciudad();
            c=(ciudad)pc.eliminar();
            System.out.println(c.toString());
            if(!c.colaFarmacia.esVacia()){
                JOptionPane.showMessageDialog(null, "Si hay datos en la ciudad!");
                //ban=1;
            }else{
                JOptionPane.showMessageDialog(null, "No hay datos en la ciudad!");
            }
            aux.adicionar(c);
        }
        /*if(ban==1){
            JOptionPane.showMessageDialog(null, "El departamento si esta registrado!");
        }else{
            JOptionPane.showMessageDialog(null, "El departamento no esta registrado!");
        }*/
        while(!aux.esVacia()){
            pc.adicionar(aux.eliminar());
        }

        while(!aux.esVacia()){
            pc.adicionar(aux.eliminar());
        }

        
        //llenarJtable2(pc,nombre);
        p1.getPila(pc);

    }//GEN-LAST:event_buttonbuscarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       Principal1 p1=new Principal1();
      
        String nombre=campobuscar.getText();

        
        llenarJtable2(pc,nombre);
        p1.getPila(pc);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void campobuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campobuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campobuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PANEL8.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PANEL8.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PANEL8.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PANEL8.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PANEL8().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton buttonbuscar;
    private javax.swing.JTextField campobuscar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
 void borrartabla(){
     DefaultTableModel modelo=(DefaultTableModel)Tabla.getModel();
     while(modelo.getRowCount()>0)modelo.removeRow(0);
 } 
    public void llenarJtable2(pila p,String x){
        Principal1 p1=new Principal1();
      pila aux=new pila(100);
      borrartabla();
      DefaultTableModel modelo = (DefaultTableModel) Tabla.getModel();
      while (!p.esVacia() ){  
         ciudad c1=new ciudad();
         c1=(ciudad)p.eliminar();
         if(x.equals(c1.getNombre())){
           
             while(!c1.colaFarmacia.esVacia()){
                Farmacia f=new Farmacia();
                f=(Farmacia)c.eliminar();
                
               Object fila[]=new Object[3];
               fila[0]=f.getNombreFar();
               fila[1]=f.getUbicacion();
               fila[2]=f.getNrInventario();
               modelo.addRow(fila);
               auxc.adicionar(f);                 
             }
              while(!auxc.esVacia()){
                 c1.colaFarmacia.adicionar(auxc.eliminar());
         }
         
         aux.adicionar(c1);
         }else{
             aux.adicionar(c1);
         }
         
      }
      Tabla.setModel(modelo);
      while(!aux.esVacia()){
          p.adicionar(aux.eliminar());
      }
      p1.getPila(p);
    }

}
