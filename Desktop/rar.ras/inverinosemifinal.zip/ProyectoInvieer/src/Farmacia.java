
public class Farmacia {
    private String nombreFar,ubicacion;
    private int nroCliente;

    public Farmacia(String nombreFar, String ubicacion, int nroCliente) {
        this.nombreFar = nombreFar;
        this.ubicacion = ubicacion;
        this.nroCliente = nroCliente;
    }

    public Farmacia() {
    }
    public String toString(){
        return "Nombre: "+nombreFar+" "+"Ubicacion: "+ubicacion+" "+"Cantidad de inventario: "+nroCliente;
    }
    

    public String getNombreFar() {
        return nombreFar;
    }

    public void setNombreFar(String nombreFar) {
        this.nombreFar = nombreFar;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getNrInventario() {
        return nroCliente;
    }

    public void setNrInventario(int nroCliente) {
        this.nroCliente = nroCliente;
    }
    
    
    
}
